package reversi;

public class ReversiController implements IController
{

	@Override
	public void initialise(IModel model, IView view) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void startup() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void squareSelected(int player, int x, int y) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doAutomatedMove(int player) {
		// TODO Auto-generated method stub
		
	}
	


}

