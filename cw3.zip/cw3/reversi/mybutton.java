package reversi;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.BorderFactory;
import javax.swing.JButton;


public class mybutton extends JButton{


	Color borderColor;
	Color whiteColor;
	Color blackColor;

	
	
	@SuppressWarnings("deprecation")
	public mybutton(int x, int y) {
		this.setLabel(String.valueOf(x) +"-"+ String.valueOf(y));
		this.setBackground(Color.GREEN);
		this.setPreferredSize(new Dimension(50,50));	
		this.setBorder(BorderFactory.createLineBorder(Color.BLACK));
	}



}
